package com.example.quizzie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {
    EditText LU,LP;
    TextView QLOGO,NUSER,REGBTN,FPASSBTN;
    Button LOGINBTN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        LU = findViewById(R.id.username);
        LP = findViewById(R.id.password);
        QLOGO =
    }
}
